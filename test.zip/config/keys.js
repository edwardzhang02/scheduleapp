module.exports = {
    MongoURI: 'mongodb+srv://edward_zhang:ugutyascf@cluster0.kawft.mongodb.net/<Cluster0>?retryWrites=true&w=majority'
}